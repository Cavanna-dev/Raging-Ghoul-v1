-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 12 Novembre 2014 à 14:01
-- Version du serveur :  5.6.20
-- Version de PHP :  5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `raging-ghoul-v1`
--
CREATE DATABASE IF NOT EXISTS `raging-ghoul-v1` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `raging-ghoul-v1`;

-- --------------------------------------------------------

--
-- Structure de la table `bo_users`
--

DROP TABLE IF EXISTS `bo_users`;
CREATE TABLE IF NOT EXISTS `bo_users` (
`id` int(11) NOT NULL,
  `login` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(55) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Vider la table avant d'insérer `bo_users`
--

TRUNCATE TABLE `bo_users`;
--
-- Contenu de la table `bo_users`
--

INSERT INTO `bo_users` (`id`, `login`, `password`) VALUES
(1, 'admin', 'pouetpouet');

-- --------------------------------------------------------

--
-- Structure de la table `candidature`
--

DROP TABLE IF EXISTS `candidature`;
CREATE TABLE IF NOT EXISTS `candidature` (
`id` int(11) NOT NULL,
  `nom` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(3) NOT NULL,
  `situation` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `pseudo` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `armurerie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `race` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `classe` int(2) NOT NULL,
  `specialisation_p` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `specialisation_s` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier1` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier1_niv` int(3) NOT NULL,
  `metier2` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier2_niv` int(3) NOT NULL,
  `histoire` text COLLATE utf8_unicode_ci NOT NULL,
  `parcours` text COLLATE utf8_unicode_ci NOT NULL,
  `optimisation` text COLLATE utf8_unicode_ci NOT NULL,
  `contribution` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Vider la table avant d'insérer `candidature`
--

TRUNCATE TABLE `candidature`;
--
-- Contenu de la table `candidature`
--

INSERT INTO `candidature` (`id`, `nom`, `prenom`, `age`, `situation`, `pseudo`, `armurerie`, `race`, `classe`, `specialisation_p`, `specialisation_s`, `metier1`, `metier1_niv`, `metier2`, `metier2_niv`, `histoire`, `parcours`, `optimisation`, `contribution`) VALUES
(1, 'Cavanna', 'Christophe', 24, 'Etudiant', 'VilKarij', 'http://eu.battle.net/wow/fr/character/hyjal/Vilkarij/advanced', 'Troll', 6, 'Arcane', 'Givre', 'Couture', 600, 'Enchantement', 600, 'test', 'test', 'test', 'test'),
(2, 'Meunier', 'Maxime', 24, 'Etudiant', 'Swoka Noob', 'http://eu.battle.net/wow/fr/character/hyjal/noob/advanced', 'Orc', 10, 'cÃ© koi', 'vasy samsooul', 'Minage', 1, 'Travail du Cuir', 2, 'josef', 'josef', 'josef', 'josef');

-- --------------------------------------------------------

--
-- Structure de la table `classes`
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
`id` int(11) NOT NULL,
  `name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(55) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Vider la table avant d'insérer `classes`
--

TRUNCATE TABLE `classes`;
--
-- Contenu de la table `classes`
--

INSERT INTO `classes` (`id`, `name`, `logo`, `color`) VALUES
(1, 'Chaman', 'cham_logo.png', 'rgb(80, 144, 229)'),
(2, 'Chevalier de la Mort', 'dk_logo.png', 'rgb(214, 17, 17)'),
(3, 'Druide', 'drood_logo.png', 'rgb(244, 160, 34)'),
(4, 'Voleur', 'fufu_logo.png', 'rgb(255, 245, 61)'),
(5, 'Chasseur', 'hunt_logo.png', 'rgb(74, 193, 38)'),
(6, 'Mage', 'mage_logo.png', 'rgb(0, 233, 255)'),
(7, 'Moine', 'moine_logo.jpg', 'rgb(179, 229, 221)'),
(8, 'Paladin', 'pal_logo.png', 'rgb(255, 193, 231)'),
(9, 'Prêtre', 'priest_logo.png', 'rgb(242, 242, 242)'),
(10, 'Guerrier', 'war_logo.png', 'rgb(186, 118, 67)'),
(11, 'Démoniste', 'warlock_logo.png', 'rgb(247, 86, 239)');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `bo_users`
--
ALTER TABLE `bo_users`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `candidature`
--
ALTER TABLE `candidature`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `classes`
--
ALTER TABLE `classes`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `bo_users`
--
ALTER TABLE `bo_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `candidature`
--
ALTER TABLE `candidature`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `classes`
--
ALTER TABLE `classes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

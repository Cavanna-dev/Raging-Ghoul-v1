-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 10 Novembre 2014 à 13:29
-- Version du serveur :  5.6.20
-- Version de PHP :  5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `raging-ghoul-v1`
--

-- --------------------------------------------------------

--
-- Structure de la table `candidature`
--

CREATE TABLE IF NOT EXISTS `candidature` (
`id` int(11) NOT NULL,
  `nom` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(3) NOT NULL,
  `situation` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `pseudo` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `armurerie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `race` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `classe` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `specialisation_p` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `specialisation_s` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier1` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier1_niv` int(3) NOT NULL,
  `metier2` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier2_niv` int(3) NOT NULL,
  `histoire` text COLLATE utf8_unicode_ci NOT NULL,
  `parcours` text COLLATE utf8_unicode_ci NOT NULL,
  `optimisation` text COLLATE utf8_unicode_ci NOT NULL,
  `contribution` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `candidature`
--
ALTER TABLE `candidature`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `candidature`
--
ALTER TABLE `candidature`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

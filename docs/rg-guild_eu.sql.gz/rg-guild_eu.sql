-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2014 at 10:58 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `raging-ghoul-v1`
--
DROP DATABASE `raging-ghoul-v1`;
CREATE DATABASE IF NOT EXISTS `raging-ghoul-v1` DEFAULT CHARACTER SET utf32 COLLATE utf32_unicode_ci;
USE `raging-ghoul-v1`;

-- --------------------------------------------------------

--
-- Table structure for table `bo_users`
--

DROP TABLE IF EXISTS `bo_users`;
CREATE TABLE IF NOT EXISTS `bo_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bo_users`
--

INSERT INTO `bo_users` (`id`, `login`, `password`) VALUES
(1, 'admin', 'pouetpouet');

-- --------------------------------------------------------

--
-- Table structure for table `candidature`
--

DROP TABLE IF EXISTS `candidature`;
CREATE TABLE IF NOT EXISTS `candidature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `prenom` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(3) NOT NULL,
  `situation` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `pseudo` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `armurerie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `race` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `classe` int(2) NOT NULL,
  `specialisation_p` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `specialisation_s` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier1` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier1_niv` int(3) NOT NULL,
  `metier2` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `metier2_niv` int(3) NOT NULL,
  `histoire` text COLLATE utf8_unicode_ci NOT NULL,
  `parcours` text COLLATE utf8_unicode_ci NOT NULL,
  `optimisation` text COLLATE utf8_unicode_ci NOT NULL,
  `contribution` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`, `logo`, `color`) VALUES
(1, 'Druide', 'drood_logo.png', '#ff7c0a'),
(2, 'Chevalier de la Mort', 'dk_logo.png', '#c41e3b'),
(3, 'Chaman', 'cham_logo.png', '#2359ff'),
(4, 'Voleur', 'fufu_logo.png', '#fff468'),
(5, 'Chasseur', 'hunt_logo.png', '#aad372'),
(6, 'Mage', 'mage_logo.png', '#68ccef'),
(7, 'Moine', 'moine_logo.jpg', '#00ffba'),
(8, 'Paladin', 'pal_logo.png', '#f48cba'),
(9, 'Prêtre', 'priest_logo.png', '#f0ebe0'),
(10, 'Guerrier', 'war_logo.png', '#c69b6d'),
(11, 'Démoniste', 'warlock_logo.png', '#9382c9');

-- --------------------------------------------------------

--
-- Table structure for table `specialisations`
--

DROP TABLE IF EXISTS `specialisations`;
CREATE TABLE IF NOT EXISTS `specialisations` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf32_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf32_unicode_ci NOT NULL,
  `isRecruitable` tinyint(1) NOT NULL DEFAULT '0',
  `fk_class` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_class` (`fk_class`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci AUTO_INCREMENT=35 ;

--
-- Dumping data for table `specialisations`
--

INSERT INTO `specialisations` (`id`, `name`, `logo`, `isRecruitable`, `fk_class`) VALUES
(1, 'Equilibre', 'http://media.blizzard.com/wow/icons/56/spell_nature_starfall.jpg', 0, 1),
(2, 'Felin', 'http://media.blizzard.com/wow/icons/56/ability_druid_catform.jpg', 0, 1),
(3, 'Ours', 'http://media.blizzard.com/wow/icons/56/ability_racial_bearform.jpg', 0, 1),
(4, 'Restauration', 'http://media.blizzard.com/wow/icons/56/spell_nature_healingtouch.jpg', 0, 1),
(5, 'Sang', 'http://media.blizzard.com/wow/icons/56/spell_deathknight_bloodpresence.jpg', 0, 2),
(6, 'Givre', 'http://media.blizzard.com/wow/icons/56/spell_deathknight_frostpresence.jpg', 0, 2),
(7, 'Présence Impie', 'http://media.blizzard.com/wow/icons/56/spell_deathknight_unholypresence.jpg', 0, 2),
(8, 'Maîtrise des bêtes', 'http://media.blizzard.com/wow/icons/56/ability_hunter_bestialdiscipline.jpg', 0, 5),
(9, 'Précision', 'http://media.blizzard.com/wow/icons/56/ability_hunter_focusedaim.jpg', 0, 5),
(10, 'Survie', 'http://media.blizzard.com/wow/icons/56/ability_hunter_camouflage.jpg', 0, 5),
(11, 'Arcane', 'http://media.blizzard.com/wow/icons/56/spell_holy_magicalsentry.jpg', 0, 6),
(12, 'Feu', 'http://media.blizzard.com/wow/icons/56/spell_fire_firebolt02.jpg', 0, 6),
(13, 'Givre', 'http://media.blizzard.com/wow/icons/56/spell_frost_frostbolt02.jpg', 0, 6),
(14, 'Maître-Brasseur', 'http://media.blizzard.com/wow/icons/56/spell_monk_brewmaster_spec.jpg', 0, 7),
(15, 'Tisse-Brume', 'http://media.blizzard.com/wow/icons/56/spell_monk_mistweaver_spec.jpg', 0, 7),
(16, 'Marche-Vent', 'http://media.blizzard.com/wow/icons/56/spell_monk_windwalker_spec.jpg', 0, 7),
(17, 'Sacré', 'http://media.blizzard.com/wow/icons/56/spell_holy_holybolt.jpg', 0, 8),
(18, 'Protection', 'http://media.blizzard.com/wow/icons/56/ability_paladin_shieldofthetemplar.jpg', 0, 8),
(19, 'Vindicte', 'http://media.blizzard.com/wow/icons/56/spell_holy_auraoflight.jpg', 0, 8),
(20, 'Discipline', 'http://media.blizzard.com/wow/icons/56/spell_holy_powerwordshield.jpg', 0, 9),
(21, 'Sacré', 'http://media.blizzard.com/wow/icons/56/spell_holy_guardianspirit.jpg', 0, 9),
(22, 'Ombre', 'http://media.blizzard.com/wow/icons/56/spell_shadow_shadowwordpain.jpg', 0, 9),
(23, 'Assassinat', 'http://media.blizzard.com/wow/icons/56/ability_rogue_eviscerate.jpg', 0, 4),
(24, 'Combat', 'http://media.blizzard.com/wow/icons/56/ability_backstab.jpg', 0, 4),
(25, 'Finesse', 'http://media.blizzard.com/wow/icons/56/ability_stealth.jpg', 0, 4),
(26, 'Elementaire', 'http://media.blizzard.com/wow/icons/56/spell_nature_lightning.jpg', 0, 3),
(27, 'Amélioration', 'http://media.blizzard.com/wow/icons/56/spell_nature_lightningshield.jpg', 0, 3),
(28, 'Restauration', 'http://media.blizzard.com/wow/icons/56/spell_nature_magicimmunity.jpg', 0, 3),
(29, 'Affliction', 'http://media.blizzard.com/wow/icons/56/spell_shadow_deathcoil.jpg', 0, 11),
(30, 'Démonologie', 'http://media.blizzard.com/wow/icons/56/spell_shadow_metamorphosis.jpg', 0, 11),
(31, 'Destruction', 'http://media.blizzard.com/wow/icons/56/spell_shadow_rainoffire.jpg', 0, 11),
(32, 'Armes', 'http://media.blizzard.com/wow/icons/56/ability_warrior_savageblow.jpg', 0, 10),
(33, 'Fureur', 'http://media.blizzard.com/wow/icons/56/ability_warrior_innerrage.jpg', 0, 10),
(34, 'Protection', 'http://media.blizzard.com/wow/icons/56/ability_warrior_defensivestance.jpg', 0, 10);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `specialisations`
--
ALTER TABLE `specialisations`
  ADD CONSTRAINT `specialisations_ibfk_1` FOREIGN KEY (`fk_class`) REFERENCES `classes` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
